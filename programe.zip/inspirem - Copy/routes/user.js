const fs = require('fs');
const QRCode = require('qrcode');

module.exports = {

    userpage: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        res.render('index.ejs', {
            user: user,
            title: "welcome user"
        });
    },

    indexpage: (req, res) => {
        res.render('index.ejs');
    },

    addeventpage: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        let message = '';
        let typeqry = "SELECT * FROM etype ";
        let catqry = "SELECT * FROM ecategory ";
        
        db.query(typeqry, (err, type) => {
            if (err) {
                console.log("1 problem here");
                res.redirect('/');
            }
            db.query(catqry, (err, category) =>{
                if (err) {
                    console.log("2 problem here");
                    res.redirect('/');
                }
            
                res.render('addevent.ejs', {
                    title: "Create Event"
                    //,user: user
                    ,types: type
                    ,categories: category
                    ,message: message
                });
            });
        });


    },

    addevent: (req, res) => {
        var user = req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        } 

        if (!req.files) {
            return res.status(400).send("No files were uploaded.");
        }

        let e_name = req.body.e_name;
        let e_description = req.body.e_description;
        let e_location = req.body.e_location;
        let e_type = req.body.e_type;
        let e_category = req.body.e_category;
        let e_pmob = req.body.e_pmob;
        let e_price = req.body.e_price;
        let e_date_from =  req.body.e_date_from;
        let e_date_to =  req.body.e_date_to;
        let e_link = req.body.e_link;
        let e_retype = req.body.e_retype;
        

        let uploadedFile = req.files.image;
        let image_name = uploadedFile.name;
        let fileExtension = uploadedFile.mimetype.split('/')[1];
        
        
        let eventqry = "SELECT MAX(e_id) FROM `event` ";

        let query = "INSERT INTO `event` (e_name, e_description, e_location, e_type, e_category, uid, e_pmob, e_price, e_date_from, e_date_to, e_link, e_retype) VALUES ('" +
        e_name + "', '" + e_description + "', '" + e_location + "', '" + e_type + "', '" + e_category + "', '"+userId+"', '"+e_pmob+"', '"+e_price+"', '"+e_date_from+"', '"+e_date_to+"', '"+e_link+"', '"+e_retype+"')";
                        
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            console.log('insert success');
            console.log(result.insertId);
            var a = result.insertId;
            image_name = a + '.' + fileExtension;

            let pointqry = "UPDATE `user` SET u_point = u_point + 1 WHERE uid = '"+userId+"';";
            db.query(pointqry, (err, pointrslt) => {
                if (err) {
                    return res.status(500).send(err);
                }
                let uqry = "SELECT `u_point` FROM `user` WHERE uid='"+userId+"' ";
                db.query(uqry, (err, urslt) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    if (urslt > 10)
                    {
                        if (urslt > 20){
                            let ucatqry = "UPDATE `user` SET u_category='platinum' WHERE uid = '"+userId+"'";
                        }
                        else{
                            let ucatqry = "UPDATE `user` SET u_category='gold' WHERE uid = '"+userId+"'";
                        }
                        db.query(ucatqry, (err, ucatrslt) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                        });
                    }
                });

                
                // check the filetype before uploading it
                if (uploadedFile.mimetype === 'image/png' || uploadedFile.mimetype === 'image/jpeg' || uploadedFile.mimetype === 'image/gif') {
                    // upload the file to the /public/assets/img directory
                    uploadedFile.mv(`public/assets/img/${image_name}`, (err ) => {
                        if (err) {
                            return res.status(500).send(err);
                        }
                        let upqry = "UPDATE `event` SET `e_img`='"+ image_name +"' WHERE e_id='"+a+"'";
                        db.query(upqry, (err, results) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                            console.log("image name updated");
                            if (e_retype == 1) {
                                res.render('addseat.ejs', {
                                    e_id: a
                                });
                            }
                            else {
                                res.redirect('/');
                            }

                            
                        });
                    });
                }else {
                    console.log("invalid file format");
                }
            });

        });
    },

    vieweventpage: (req, res) => {

        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

        let message ='';
        
        let equery = "SELECT * FROM event WHERE uid='"+userId+"' ORDER BY e_id ASC";
        db.query(equery, (err, eresult) => {
            if (err) {
                res.redirect('/');
            }
            let a = eresult;
            
            if (eresult.length > 0)
            {
                let query = "SELECT DISTINCT e_location FROM event"; 
                
                // execute query
                db.query(query, (err, result) => {
                    if (err) {
                        res.redirect('/');
                    }
                    console.log(eresult.length);
                
                    res.render('viewevent.ejs', {
                        title: "View Events"
                        ,user: user
                        ,locations: result
                        ,message: message
                        ,events: eresult
                    });
                });
            }
            else{
                let query = "SELECT DISTINCT e_location FROM event"; 
                
                // execute query
                db.query(query, (err, result) => {
                    if (err) {
                        res.redirect('/');
                    }
                    console.log(eresult.length);
                
                    res.render('viewevent.ejs', {
                        title: "View Events"
                        ,user: user
                        ,locations: result
                        ,message: message
                        ,events: eresult
                    });
                });
            }
            
        });
    },

    vieweventloc: (req, res) => {

        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

               let e_location = req.body.e_location;
        let query = "SELECT * FROM event WHERE e_location='"+ e_location +"'";
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/userpage/viewevent');
            }
            res.render('vieweventloc.ejs', {
                title: "View Event by Location"
                ,events: result
                ,location: e_location
            });
        });
    },

    logout: (req, res) => {
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        req.session.destroy(function(err) {
            res.redirect("/");
         })
    },

    profile:(req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

       
        let qry = "SELECT event.e_id, event.e_name, event.e_location FROM event RIGHT JOIN interest ON event.e_id = interest.e_id WHERE interest.uid='"+userId+"' ";
        db.query(qry, (err, rslt) =>{
            if (err) {
                res.redirect('/');
            }
            
            let uquery = "SELECT * FROM user WHERE uid='"+userId+"' ";
            db.query(uquery, (err, uresult) => {
                if (err) {
                    res.redirect('/');
                }
                       
                let query = "SELECT * FROM event WHERE uid='"+userId+"' ORDER BY e_id ASC";                 
                db.query(query, (err, result) => {
                    if (err) {
                        res.redirect('/');
                    }
                    let iqry = "SELECT interest.iid FROM interest LEFT JOIN event ON interest.e_id = event.e_id WHERE event.uid = '"+userId+"' ";
                    let eqry = "SELECT eregister.ere_id FROM eregister LEFT JOIN event ON eregister.e_id = event.e_id WHERE event.uid = '"+userId+"'  ";
                    db.query(iqry, (err, irslt) => { //total number of interests
                        if (err) {
                            res.redirect('/');
                        }
                        db.query(eqry, (err, erslt) => {  //total number of registered user 
                            if (err) {
                                res.redirect('/');
                            }
                            let a = irslt.length;
                            let b = erslt.length;
                            res.render('profile.ejs', {
                                title: "Your Profile"
                                //,user: user
                                ,user: uresult[0]
                                ,events: result
                                ,ints: rslt
                                ,a: a
                                ,b: b
                            });
                        });
                    });






                                 
                });                       
            });
        });
    },
    
    editeventpage: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        let e_id = req.params.e_id;
        let query = "SELECT * FROM event WHERE e_id='"+e_id+"' ";                 
            // execute query
            db.query(query, (err, result) => {
                if (err) {
                    res.redirect('/');
                }
                    let typeqry = "SELECT * FROM etype ";
                    let catqry = "SELECT * FROM ecategory ";
        
                    db.query(typeqry, (err, type) => {
                        if (err) {
                            res.redirect('/');
                        }
                        db.query(catqry, (err, category) =>{
                            if (err) {
                                res.redirect('/');
                            }
            
                            res.render('editevent.ejs', {
                                title: "Edit Event"
                                ,types: type
                                ,categories: category
                                ,event: result[0]
                            });
                        });
                    });
                
            });
    },

    editevent: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        let e_id = req.params.e_id;
        let e_name = req.body.e_name;
        let e_description = req.body.e_description;
        let e_location = req.body.e_location;
        let e_type = req.body.e_type;
        let e_category = req.body.e_category;
        let e_pmob = req.body.e_pmob;
        let e_price = req.body.e_price;
        let e_date_from =  req.body.e_date_from;
        let e_date_to =  req.body.e_date_to;
        
        
        let query = "UPDATE `event` SET `e_name` = '" + e_name + "', `e_description` = '" + e_description + "', `e_location` = '" + e_location + "', `e_type` = '" + e_type + "', `e_category` = '" + e_category + "', `e_pmob` = '" + e_pmob + "', `e_price` = '" + e_price + "',`e_date_from` = '" + e_date_from + "',`e_date_to` = '" + e_date_to + "' WHERE `event`.`e_id` = '" + e_id + "' ";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.redirect('/profile');
        });
        

    },

    deleteevent: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

        let e_id = req.params.e_id;
        let getImageQuery = 'SELECT e_img from `event` WHERE e_id = "' + e_id + '"';
        let deleteUserQuery = 'DELETE FROM event WHERE e_id = "' + e_id + '"';
        let indeleteqry = 'DELETE FROM interest WHERE e_id = "' + e_id + '"';
        let redeleteqry = 'DELETE FROM eregister WHERE e_id = "' + e_id + '"';

        db.query(getImageQuery, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }

            let image = result[0].e_img;

            fs.unlink(`public/assets/img/${image}`, (err) => {
                if (err) {
                    return res.status(500).send(err);
                }
                db.query(indeleteqry, (err, indrslt) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    db.query(redeleteqry, (err, redrslt) => {
                        if (err) {
                            return res.status(500).send(err);
                        }
                        db.query(deleteUserQuery, (err, result) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                            res.redirect('/profile');
                        });
                    });
                });
            });
        });
    },

    singleevent: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        
        let e_id = req.params.e_id;
        let query = "SELECT * FROM event WHERE e_id='"+e_id+"'";                 
           
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }

            let iquery = "SELECT * FROM interest WHERE e_id='"+e_id+"' and uid='"+userId+"' ";
            db.query(iquery, (err, iresult) => {
                if (err) {
                    res.redirect('/');
                }             
                let rquery = "SELECT * FROM eregister WHERE e_id='"+e_id+"' and uid='"+userId+"' ";
                db.query(rquery, (err, rresult) => {
                    if (err) {
                        res.redirect('/');
                    }
                    if (result.length > 0){
                        res.render('singleevent.ejs', {
                            title: "Your Profile"
                            ,event: result[0]
                            ,user: userId
                            ,int: iresult
                            ,ereg: rresult
                        });
                    }
                });
            });
            
        });
        
    },

    interest: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

        let e_id = req.params.e_id;
        let query = "SELECT * FROM interest WHERE e_id='"+e_id+"' and uid='"+userId+"' ";
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
            if(result.length > 0){
                res.redirect('/singleevent/'+e_id);
            }else{
                let iquery = "INSERT INTO `interest`(`uid`, `e_id`) VALUES ('"+userId+"', '"+e_id+"') ";
                db.query(iquery, (err, iresult) => {
                    if (err) {
                        res.redirect('/');
                    }
                    
                    res.redirect('/singleevent/'+e_id);
                });
            }
        });    
    },

    notinterest: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

        let e_id = req.params.e_id;
        let query = "DELETE FROM `interest` WHERE e_id='"+e_id+"' and uid='"+userId+"' ";
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
            res.redirect('/singleevent/'+e_id);
        });
    },

    addseat: (req, res) => {
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }

        let e_id = req.params.e_id;
        let e_seat = req.body.e_seat;

        let query = "UPDATE `event` SET `e_seat` = '"+ e_seat +"', `e_ticket` = '"+ e_seat +"' WHERE e_id = '"+e_id+"' ";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.redirect('/');
        });
    },

    eregister: (req, res) => {
        var user =  req.session.user,
        userId = req.session.userId;
        console.log('userId='+userId);
        if(userId == null){
           res.redirect("/login");
           return;
        }
        let e_id = req.params.e_id;
        let query = "SELECT * FROM eregister WHERE e_id='"+e_id+"' and uid='"+userId+"' ";
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/');
            }
            if(result.length > 0){
                res.redirect('/singleevent/'+e_id);
            }else{
                let equery = "SELECT * FROM event WHERE e_id='"+e_id+"' ";
                db.query(equery, (err, eresult) => {
                    if (err) {
                        res.redirect('/');
                    }
                    let ticket = eresult[0].e_ticket;
                    console.log(ticket);
                    if(ticket > 0){

                        let iquery = "INSERT INTO `eregister`(`uid`, `e_id`) VALUES ('"+userId+"', '"+e_id+"') ";
                        db.query(iquery, (err, iresult) => {
                            if (err) {
                                res.redirect('/');
                            }
                            //updating the seats remaining
                            let retqry = "UPDATE `event` SET e_ticket = e_ticket - 1 WHERE e_id = '"+e_id+"';";
                            db.query(retqry, (err, rerslt) => {
                                if (err) {
                                    return res.status(500).send(err);
                                }
                                //here comes the ticket generation part
                                
                                QRCode.toDataURL(JSON.stringify({ eventid: e_id, uid: userId }),{errorCorrectionLevel:'H'},function (err, url) {    
                                    console.log(url)    
                                    res.render('ticket.ejs',{
                                        event: eresult[0]
                                        ,data:url})    
                                  }); 
                                
                            });
                        });
                    }else {
                        console.log("here are");
                        res.redirect('/singleevent/'+e_id);
                    }
                });
            }
        });

    }

};