const fs = require('fs');

module.exports = {

    adminloginpage: (req, res) => {
        res.render
        ('admin.ejs', {
            title: "Admin Login",
            message: ''
        });
    },

    adminlogin: (req, res) => {
        console.log("this is a adminlogin post");
        var message = '';
        var sess = req.session; 

        if(req.method == "POST"){
           
            var name= req.body.adname;
            var pass= req.body.adpass;
            console.log(req.body.adname);
     
            var sql="SELECT * FROM `admin` WHERE `adname`='"+name+"' and `adpass` = '"+pass+"'";                           
            db.query(sql, function(err, results){ 
                console.log(results.length);     
                if(results.length){
                    req.session.adminId = results[0].adid;
                    req.session.admin = results[0];
                    console.log(results[0].adid);
                    res.redirect('/admin/adminpage');
                }
                else{
                     message = 'Wrong Name or Password';
                     res.render('admin.ejs',{message: message});
                }
                 
            });
        } else {
            res.render('admin.ejs',{message: message});
        }
    },

    adminpage: (req, res, next) => {
        var admin =  req.session.admin,
        adminId = req.session.adminId;
        console.log('adminId='+adminId);
        if(adminId == null){
           res.redirect("/admin");
           return;
        }
     
        var sql="SELECT * FROM `admin` WHERE `adid`='"+adminId+"'";
     
        db.query(sql, function(err, results){
           res.render
           ('adminpage.ejs', {
               admin: admin,
               title: "welcome to Adminpage"
            });    
        }); 
    },

    addtype: (req, res) => {
      var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
         }

         let query = "SELECT * FROM `etype` ORDER BY type_id ASC"; // query database to get all the players

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/admin/adminpage');
            }
            console.log(result.length)
            res.render('adminaddtype.ejs', {
                title: "Add Types"
                ,types: result
            });
        });

   
    },

    typeadd: (req, res) => {
        var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
        }

        var typename = req.body.name;

        let query = "SELECT * FROM `etype` WHERE type_name='"+typename+"' ";
        
        db.query(query, (err, result) => {
            console.log(result.length);
        if (err) {
            return res.status(500).send(err);
        }
        if (result.length > 0) {
            console.log('Alredy exists');
            res.redirect('/admin/adminpage/addtype');
        } 
            
        else{
                let addquery = "INSERT INTO `etype` (type_name) VALUES ('" +typename+ "')";
                db.query(addquery, (err, types) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    console.log('type insert successfull');
                    console.log(types);
                    res.redirect('/admin/adminpage/addtype')
                    
                });
            }

        });

    },

    addcategory: (req, res) => {
        var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
         }

         let query = "SELECT * FROM `ecategory` ORDER BY cat_id ASC"; // query database to get all the players

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/admin/adminpage');
            }
            console.log(result.length)
            res.render('adminaddcategory.ejs', {
                title: "Add Category"
                ,categories: result
            });
        });

    },

    categoryadd: (req, res) => {
        var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
        }

        var catname = req.body.name;

        let query = "SELECT * FROM `ecategory` WHERE cat_name='"+catname+"' ";
        
        db.query(query, (err, result) => {
            console.log(result.length);
        if (err) {
            return res.status(500).send(err);
        }
        if (result.length > 0) {
            console.log('Alredy exists');
            res.redirect('/admin/adminpage/addcategory');
        } 
            
        else{
                let addquery = "INSERT INTO `ecategory` (cat_name) VALUES ('" +catname+ "')";
                db.query(addquery, (err, categories) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    console.log('type insert successfull');
                    console.log(categories);
                    res.redirect('/admin/adminpage/addcategory')
                    
                });
            }

        });

    },

    viewuser: (req, res) => {
        var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
         }

        let query = "SELECT * FROM `user` ORDER BY uid ASC"; // query database to get all the players

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/admin');
            }
            console.log(result.length)
            res.render('adminviewuser.ejs', {
                title: "View Users"
                ,users: result
            });
        });
    },

    viewevent: (req, res) => {
        var adminId = req.session.adminId;
        if(adminId == null){
             res.redirect("/admin");
            return;
         }

        let query = "SELECT * FROM `event` ORDER BY e_id ASC"; 

        // execute query
        db.query(query, (err, result) => {
            if (err) {
                res.redirect('/admin');
            }
            console.log(result.length)
            res.render('adminviewevent.ejs', {
                title: "View Events"
                ,events: result
            });
        });
    },

    adminlogout: (req, res) => {
        req.session.destroy(function(err) {
            res.redirect("/admin");
         })
    }

};