const fs = require('fs');

module.exports = {

    adduserpage: (req, res) => {
        res.render
        ('register.ejs',{
            title:"Welcome to programe",
            message:''
            ,useremail: ''
        });
    },

    adduser: (req, res) => {

        
        let message = '';
        let fname = req.body.fname;
        let lname = req.body.lname;
        let email = req.body.email;
        let number = req.body.number;
        let password = req.body.password;
        
        
        let userEmailQuery = "SELECT * FROM `user` WHERE email = '" + email + "'";
        db.query(userEmailQuery, (err,result) =>{
            if (err){
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                message = 'email already exists';
                res.redirect('/login')
            }else {
                let query = "INSERT INTO `user` (fname, lname, email, number, password) VALUES ('" +
                            fname + "', '" + lname + "', '" + email + "', '" + number + "', '" + password + "')";
                        db.query(query, (err, result) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                            console.log('insert success');
                            console.log(result);

                            let userEmailQuery = "SELECT * FROM `user` WHERE email = '" + email + "'";
                            db.query(userEmailQuery, (err,results) =>{
                                if (err){
                                    return res.status(500).send(err);
                                }
                                if (results.length > 0) {
                                    console.log('at the begining of session from register');
                                    req.session.userId = results[0].uid;
                                    req.session.user = results[0];
                                    console.log(results[0].uid);
                                    res.redirect('/');                
                                }
                            });
                        });
            }
        });
    },

    loginpage: (req, res) => {
        res.render('login.ejs',{
            title:"programe | Login"
            ,message:''
            });
    },

    login: (req, res) => {
        let email = req.body.email;
        let password = req.body.password;
        let query = "SELECT * FROM `user` WHERE email = '" + email + "' and password = '"+password+"' ";
        db.query(query, (err,result) =>{
            if (err){
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                console.log('User Login successfull');
                req.session.userId = result[0].uid;
                req.session.user = result[0];
                console.log(result[0].uid);
                res.redirect('/');
            }
            else{
                res.render('login.ejs',{
                    message: 'User name Or Password Incorrect'
                });
            }
        });
    },

    fromgoogle: (req, res) => {
        let useremail = req.params.email;
        console.log(useremail);
        let userEmailQuery = "SELECT * FROM `user` WHERE email = '" + useremail + "'";
        db.query(userEmailQuery, (err,result) =>{
            if (err){
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                console.log('already existing user');
                req.session.userId = result[0].uid;
                req.session.user = result[0];
                console.log(result[0].uid);
                res.redirect('/');
                
                
            }else {
                res.render('register.ejs', {
                    title: "Register Now",
                    useremail: useremail,
                    message: ''
                })
            }
        });
    },

    aboutpage: (req, res) => {
        res.render('about.ejs');
    },

    testpage: (req, res) => {
        res.render('test.ejs');
    },

    test: (req, res) => {
        let a = req.body.optradio;
        console.log(a);
        console.log(typeof(a));
    }

};