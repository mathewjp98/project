function checkIfLoggedIn(){
    firebase.auth().onAuthStateChanged(function(user){
        if (user){
            console.log( 'User Signed in' )
            console.log(user)
            document.getElementById('google-signin')
            .setAttribute('style', 'display: none; visibility: hidden')
            document.getElementById('signout')
            .setAttribute('style', 'display: inline-block; visibility: visible')
        } 
        else {
            console.log('user not signed in')

            document.getElementById('google-signin')
            .setAttribute('style', 'display: inline-block; visibility: visible')
            document.getElementById('signout')
            .setAttribute('style', 'display: none; visibility: hidden')
        }
    })
}

window.onload = function(){
    checkIfLoggedIn()
}

function signout(){
    firebase.auth().signOut()

    checkIfLoggedIn()
}

function signInWithGoogle(){
    var googleAuthProvider = new firebase.auth.GoogleAuthProvider

    firebase.auth().signInWithPopup(googleAuthProvider)
            .then( function(data){
                console.log(data)
                var idToken = data.credential.idToken
                console.log(idToken)
                
                
                checkIfLoggedIn()
            })
            .catch( function(error) {
                console.log(error)
            })
}