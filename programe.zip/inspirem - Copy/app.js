const express = require('express');
const fileUpload = require('express-fileupload');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const admin = require('firebase-admin');
const session = require('express-session');
const app = express();

const {testpage, test, adduserpage, adduser, loginpage, login, fromgoogle, aboutpage} = require('./routes/index');
const {adminloginpage, adminlogin, adminpage, addtype, typeadd, addcategory, categoryadd, viewuser, viewevent, adminlogout} = require('./routes/admin');
const {indexpage, userpage, addeventpage, addevent, vieweventpage, vieweventloc, logout, profile, editeventpage, deleteevent, editevent, singleevent, interest, notinterest, addseat, eregister} = require('./routes/user');


const port = 5000;



// create connection to database

const db = mysql.createConnection ({
    host: 'localhost',
    user: 'root',
    password: '',
    database: ''
});

// connect to database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;


// configure middleware
app.set('port', process.env.port || port); // set express to use this port
app.set('views', __dirname + '/views'); // set express to look in this folder to render our view
app.set('view engine', 'ejs'); // configure template engine
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()); // parse form data client
app.use(express.static(path.join(__dirname, 'public'))); // configure express to use public folder
app.use(fileUpload()); // configure fileupload
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: 
    true,
    cookie: { maxAge: 600000 }
  }))

  /*function isAuthenticated(req, res, next){}*/

// routes for the app
app.get('/', indexpage);
app.get('/register', adduserpage);
app.post('/register', adduser);
app.get('/login', loginpage);
app.post('/login', login);
app.get('/admin', adminloginpage);
app.post('/admin', adminlogin);
app.get('/admin/adminpage', adminpage);
app.get('/admin/adminpage/addtype', addtype);
app.get('/admin/adminpage/addcategory', addcategory);
app.get('/admin/adminpage/viewuser', viewuser);
app.get('/admin/adminpage/viewevent', viewevent);
app.post('/addtype', typeadd);
app.post('/addcategory', categoryadd);
app.get('/admin/logout', adminlogout);
app.get('/user/:email', fromgoogle)
app.get('/userpage', userpage);
app.get('/userpage/addevent', addeventpage);
app.post('/userpage/addevent', addevent);
app.get('/userpage/viewevent', vieweventpage);
app.post('/userpage/viewevent', vieweventloc);
app.get('/logout', logout);
app.get('/profile', profile);
app.get('/profile/edit/:e_id', editeventpage);
app.get('/profile/delete/:e_id', deleteevent);
app.post('/profile/edit/:e_id', editevent);
app.get('/about', aboutpage);
app.get('/singleevent/:e_id', singleevent);
app.get('/event_int/:e_id', interest);
app.get('/event_notint/:e_id', notinterest);
app.get('/test', testpage);
app.post('/test', test);
app.post('/addevent/addseat/:e_id', addseat);
app.get('/event_register/:e_id', eregister);



// set the app to listen on the port
app.listen(port, () => {
    console.log(`Server running on port: ${port}`);
});